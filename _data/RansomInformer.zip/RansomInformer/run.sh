#!/bin/bash

cd /home/RansomInformer/

/usr/bin/python3 auto.py