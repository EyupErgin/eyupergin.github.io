import requests
import json
import re
import time
from urllib.parse import unquote
import uuid
from PIL import Image, ImageDraw, ImageFont
from tld import get_tld

def get_remote_posts():
    try:
        response = requests.get("https://raw.githubusercontent.com/joshhighet/ransomwatch/main/posts.json")
        if response.status_code == 200:
            return response.json()
        else:
            print("Unable to fetch remote posts. Status code:", response.status_code)
    except requests.RequestException as e:
        print("Error fetching remote posts:", e)
    return None

def get_db_from_file():
    with open("main/groups/groups.json", "r") as file:
        db = json.load(file)
    return db

def update_group_name(posts):
    db = get_db_from_file()

    for post in posts:
        for entry in db:
            if post["group_name"] == entry["group_name"]:
                post["group_name"] = entry["new_group_name"]
                break
    
    return posts

def get_domain_category(domain):
    try:
        url = f"https://cyber-xray.com/api/v2/main/topbar/{domain}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            category = data.get("category", None)
            return category
        else:
            print("Unable to fetch domain category. Status code:", response.status_code)
    except requests.RequestException as e:
        print("Error fetching domain category:", e)
    return None

def clean_domain(post_title):
    regex = r'\b((?=[a-z0-9-]{1,63}\.)(xn--)?[a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,63}'
    match = re.search(regex, post_title)
    if match:
        return match.group()
    return None


def get_country_from_domain(domain):
    try:
        tld = get_tld(f"http://{domain}", as_object=True)
        # TLD'yi veritabanındaki TLD'lerle karşılaştır
        if tld:
            with open("main/tlds/tlds.json", "r") as file:
                tlds_data = json.load(file)
                for country_data in tlds_data:
                    if tld.tld in country_data['tlds']:
                        country = country_data['countryCode']
                        formatted_country = format_country_name(country)  # Ülke adını formatla
                        return formatted_country
    except Exception as e:
        print(f"Error getting TLD: {e}")
    
    return "Unknown"  # Eşleşme yoksa bilinmeyen olarak işaretle

def format_country_name(country):
    # Gelen ülke adını istediğimiz formata dönüştür
    words = country.split()
    formatted_words = [words[0].capitalize()] + [word.capitalize() if word.lower() not in ["and", "of", "the"] else word.lower() for word in words[1:]]
    return " ".join(formatted_words)

def generate_report(post):
    clean_title = re.sub(r'(https?:\/\/(www\.)?)|www\.?', '', post["post_title"])
    clean_group_name = post['group_name'].replace(" ", "")
    domain = clean_domain(clean_title)

    if domain:
        categories = get_domain_category(domain)
        if categories:
            category = ', '.join(categories)
            category = category.replace("'", "")
            category_info = f"*Victim's Sector:* {category}\n"
        else:
            category_info = "*Victim's Sector:* Unknown\n"

        country = get_country_from_domain(domain)
        country_info = f"*Victim's Country:* {country}\n" if country != "Unknown" else "*Victim's Country:* Unknown\n"
        

        message = (
            "🚨 *New Ransomware Attack Discovered!*\n\n"
            "⚔️ *Ransomware Attack Info:*\n"
            f"*Victim:* {clean_title}\n"
            f"*Attacker:* {post['group_name']} Ransomware Group\n"
            f"*Release Date:* {post['discovered'][:16]}\n\n"
            "📈 *Victim Info:*\n"
            f"{category_info}"
            f"{country_info}\n"  # Ülke bilgisinin eklenmesi
            "📅 *Detection Info:*\n"
            f"*Detection Date:* {post['discovered'][:16]}\n\n"
            "🕵️‍♂️ *RansomInformer's Finding Note:* \n"
            f"According to the findings obtained by RansomInformer through Threat Intelligence activities conducted on Deepweb and Darkweb, {post['group_name']} Ransomware Group has reported that it has encrypted the data belonging to the institution or organisation specified as the victim in the above text and demanded a ransom.\n\n"
            f"#{clean_group_name} #Ransomware #Attack"
        )
        return message
    
    message = (
        "🚨 *New Ransomware Attack Discovered!*\n\n"
        "⚔️ *Ransomware Attack Info:*\n"
        f"*Victim:* {clean_title}\n"
        f"*Attacker:* {post['group_name']} Ransomware Group\n"
        f"*Release Date:* {post['discovered'][:16]}\n\n"
        "📅 *Detection Info:*\n"
        f"*Detection Date:* {post['discovered'][:16]}\n\n"
        "🕵️‍♂️ *RansomInformer's Finding Note:* \n"
        f"According to the findings obtained by RansomInformer through Threat Intelligence activities conducted on Deepweb and Darkweb, {post['group_name']} Ransomware Group has reported that it has encrypted the data belonging to the institution or organisation specified as the victim in the above text and demanded a ransom.\n\n"
        f"#{clean_group_name} #Ransomware #Attack"
    )
    return message

def clean_url_encoding(posts):
    for post in posts:
        post["post_title"] = unquote(post["post_title"])
    return posts

def create_image_with_text(post):
    im = Image.open("core/modules/image/base.png")
    font = ImageFont.truetype("core/modules/font/bicubik.otf", 27)
    draw = ImageDraw.Draw(im)
    
    clean_title = re.sub(r'(https?:\/\/(www\.)?)|www\.?', '', post["post_title"])
    clean_title = clean_title.split('/')[0]  # URL'nin sadece ana kısmını al
    clean_group_name = post['group_name'] + " Ransomware Group"
    release_date = post['discovered'][:16]  # İlk 16 karakteri al

    draw.text((180, 256), f"{clean_title}", fill='white', font=font)
    draw.text((258, 298), f"{clean_group_name}", fill='white', font=font)
    draw.text((343, 340), f"{release_date}", fill='white', font=font)
    
    image_uuid = str(uuid.uuid4())  # Benzersiz bir UUID oluştur
    image_path = f"temp/{image_uuid}.png"
    im.save(image_path)
    
    return image_uuid, image_path

def job():
    remote_posts = get_remote_posts()
    local_posts = get_db_from_file()

    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)
    print(current_time, "-----------------------------")
    print(current_time, "INFO: Veri taraması başladı.")

    remote_posts = get_remote_posts()

    if remote_posts:
        try:
            with open("posts.json", "r") as file:
                local_posts = json.load(file)
        except FileNotFoundError:
            local_posts = []

        new_posts = [post for post in remote_posts if post not in local_posts]

        if new_posts:
            updated_posts = update_group_name(new_posts)
            updated_posts = clean_url_encoding(updated_posts)
            updated_posts = [post for post in remote_posts if post not in local_posts]

            with open("posts.json", "w") as file:
                json.dump(remote_posts, file, indent=4)
            
            for post in updated_posts:
                image_uuid, image_path = create_image_with_text(post)
                message = generate_report(post)
                send_telegram_message_with_image("6731284416:AAFmkbXQB1K3Zohdg3utYn_Z6aiLax1IPYc", "@ransominformer", message, image_path, image_uuid)
                                
                t = time.localtime()
                current_time = time.strftime("%H:%M:%S", t)
                print(current_time, "INFO: Yeni veri gönderildi.")

            else:
                t = time.localtime()
                current_time = time.strftime("%H:%M:%S", t)
                print(current_time, "INFO: Yeni veri bulunamadı.")
        else:
            t = time.localtime()
            current_time = time.strftime("%H:%M:%S", t)
            print(current_time, "INFO: Yeni veri alınamadı.")
    else:
        t = time.localtime()
        current_time = time.strftime("%H:%M:%S", t)
        print(current_time, "INFO: Yeni veri alınamadı.")

def send_telegram_message_with_image(bot_api_key, channel_name, text, image_path, image_uuid):
    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)
    url = f"https://api.telegram.org/bot{bot_api_key}/sendPhoto"
    files = {'photo': open(image_path, 'rb')}
    data = {
        'chat_id': channel_name,
        'caption': text,
        'parse_mode': 'Markdown',
        'disable_notification': True
    }
    response = requests.post(url, data=data, files=files)
    
    if response.status_code == 200:
        print(current_time, "INFO: Resim başarıyla gönderildi.")
    else:
        print(current_time, "ERROR: Resim gönderilirken hata yaşandı. Hata kodu:", response.status_code)

job()
