import requests
import json
import re
import time
from urllib.parse import unquote

def get_remote_posts():
    try:
        response = requests.get("https://raw.githubusercontent.com/joshhighet/ransomwatch/main/posts.json")
        if response.status_code == 200:
            return response.json()
        else:
            print("Unable to fetch remote posts. Status code:", response.status_code)
    except requests.RequestException as e:
        print("Error fetching remote posts:", e)
    return None

def get_db_from_file():
    with open("groups.json", "r") as file:
        db = json.load(file)
    return db

def update_group_name(posts):
    db = get_db_from_file()

    for post in posts:
        for entry in db:
            if post["group_name"] == entry["group_name"]:
                post["group_name"] = entry["new_group_name"]
                break
    
    return posts

def clean_domain(post_title):
    regex = r'\b((?=[a-z0-9-]{1,63}\.)(xn--)?[a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,63}'
    match = re.search(regex, post_title)
    if match:
        return match.group()
    return None

def generate_report(post):
    clean_title = re.sub(r'(https?:\/\/(www\.)?)|www\.?', '', post["post_title"])
    domain = clean_domain(clean_title)

    if domain:
        message = (
            "🚨 *New Ransomware Attack Discovered!*\n\n"
            "⚔️ *Ransomware Attack Info:*\n"
            f"*Victim:* {clean_title}\n"
            f"*Attacker:* {post['group_name']} Ransomware Group\n"
            f"*Release Date:* {post['discovered'][:16]}\n\n"
            "📅 *Detection Info:*\n"
            f"*Detection Date:* {post['discovered'][:16]}\n"
        )
        return message
    
    message = (
        "🚨 *New Ransomware Attack Discovered!*\n\n"
        "⚔️ *Ransomware Attack Info:*\n"
        f"*Victim:* {clean_title}\n"
        f"*Attacker:* {post['group_name']} Ransomware Group\n"
        f"*Release Date:* {post['discovered'][:16]}\n\n"
        "📅 *Detection Info:*\n"
        f"*Detection Date:* {post['discovered'][:16]}\n"
    )
    return message

def clean_url_encoding(posts):
    for post in posts:
        post["post_title"] = unquote(post["post_title"])
    return posts

def send_telegram_message_batch(bot_api_key, channel_name, messages):
    url = f"https://api.telegram.org/bot{bot_api_key}/sendMessage"

    for message in messages:
        payload = {
            "chat_id": channel_name,
            "text": message,
            "parse_mode": "Markdown"
        }
        requests.post(url, json=payload)
        time.sleep(3)

def send_telegram_messages(bot_api_key, channel_name, messages):
    batch_size = 20
    message_batches = [messages[i:i + batch_size] for i in range(0, len(messages), batch_size)]

    for batch in message_batches:
        send_telegram_message_batch(bot_api_key, channel_name, batch)
        time.sleep(10)

def job():
    remote_posts = get_remote_posts()
    local_posts = get_db_from_file()

    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)
    print(current_time, "-----------------------------")
    print(current_time, "INFO: Veri Taraması Başladı.")

    remote_posts = get_remote_posts()

    if remote_posts:
        try:
            with open("posts.json", "r") as file:
                local_posts = json.load(file)
        except FileNotFoundError:
            local_posts = []

        new_posts = [post for post in remote_posts if post not in local_posts]

        if new_posts:
            updated_posts = update_group_name(new_posts)
            updated_posts = clean_url_encoding(updated_posts)
            updated_posts = [post for post in remote_posts if post not in local_posts]

            with open("posts.json", "w") as file:
                json.dump(remote_posts, file, indent=4)
            
            messages_to_send = [generate_report(post) for post in updated_posts if post not in local_posts]
            if messages_to_send:
                send_telegram_messages("6731284416:AAFmkbXQB1K3Zohdg3utYn_Z6aiLax1IPYc", "@ransominformer", messages_to_send)
                t = time.localtime()
                current_time = time.strftime("%H:%M:%S", t)
                print(current_time, "INFO: Yeni veri gönderildi.")
            else:
                t = time.localtime()
                current_time = time.strftime("%H:%M:%S", t)
                print(current_time, "INFO: Yeni veri bulunamadı.")
        else:
            t = time.localtime()
            current_time = time.strftime("%H:%M:%S", t)
            print(current_time, "INFO: Yeni veri alınamadı.")
    else:
        t = time.localtime()
        current_time = time.strftime("%H:%M:%S", t)
        print(current_time, "INFO: Yeni veri alınamadı.")

job()
